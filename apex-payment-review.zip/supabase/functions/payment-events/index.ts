// POST /payment-events   — called by the payment provider, not by the browser.
// (Provider requires the delivery URL not contain its name.)
//
// This is the ONLY code path that can mark an invoice paid automatically.
// It trusts nothing in the body until the HMAC signature verifies, and it
// re-fetches the transaction from Helcim before writing anything.
//
// Helcim signature scheme (Standard Webhooks):
//   signed  = `${webhook-id}.${webhook-timestamp}.${rawBody}`
//   key     = base64-decode(HELCIM_WEBHOOK_VERIFIER_TOKEN)
//   sig     = base64(HMAC-SHA256(key, signed))
//   header  = "v1,<sig> v2,<sig>"  — any entry may match
import { createClient } from "jsr:@supabase/supabase-js@2";
import { reconcileAmount, looksACH } from "../_shared/feesaver.ts";

const HELCIM_API = "https://api.helcim.com/v2";

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

  const rawBody   = await req.text();
  const whId      = req.headers.get("webhook-id") ?? "";
  const whTs      = req.headers.get("webhook-timestamp") ?? "";
  const whSigHdr  = req.headers.get("webhook-signature") ?? "";

  if (!whId || !whTs || !whSigHdr) return new Response("Missing signature headers", { status: 400 });

  // ── 1. Replay window: reject anything older than 5 minutes ─────────────────
  const ageSec = Math.abs(Date.now() / 1000 - Number(whTs));
  if (!Number.isFinite(ageSec) || ageSec > 300) return new Response("Stale", { status: 400 });

  // ── 2. HMAC verification ────────────────────────────────────────────────────
  const verifierB64 = Deno.env.get("HELCIM_WEBHOOK_VERIFIER_TOKEN")!;
  const keyBytes = Uint8Array.from(atob(verifierB64), (c) => c.charCodeAt(0));
  const key = await crypto.subtle.importKey("raw", keyBytes, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sigBuf = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(`${whId}.${whTs}.${rawBody}`));
  const expected = btoa(String.fromCharCode(...new Uint8Array(sigBuf)));

  const presented = whSigHdr.split(" ").map((s) => s.split(",")[1] ?? "");
  if (!presented.some((s) => timingSafeEqual(s, expected))) {
    return new Response("Bad signature", { status: 401 });
  }

  // ── 3. Idempotency: same webhook-id twice is a no-op ────────────────────────
  let payload: Record<string, unknown>;
  try { payload = JSON.parse(rawBody); } catch { return new Response("Bad JSON", { status: 400 }); }
  const eventType = String(payload.type ?? "");

  const { error: dupErr } = await sb.from("payment_webhook_events")
    .insert({ webhook_id: whId, event_type: eventType, payload });
  if (dupErr) return new Response("ok (duplicate)", { status: 200 });   // already processed

  // ── 4. Only card/ACH transaction events matter to us ───────────────────────
  const data = (payload.data ?? {}) as Record<string, unknown>;
  const txnId = String(data.id ?? data.transactionId ?? "");
  if (!txnId || !/cardTransaction|bankTransaction|transaction/i.test(eventType)) {
    await markProcessed(sb, whId, `ignored:${eventType}`);
    return new Response("ok", { status: 200 });
  }

  // ── 5. Never trust the webhook body for money. Re-fetch from Helcim. ───────
  const isBank = /bank/i.test(eventType);
  const path = isBank ? `ach/transactions/${txnId}` : `card-transactions/${txnId}`;
  const tRes = await fetch(`${HELCIM_API}/${path}`, {
    headers: { "api-token": Deno.env.get("HELCIM_ADMIN_API_TOKEN")!, "accept": "application/json" },
  });
  if (!tRes.ok) { await markProcessed(sb, whId, `fetch_failed:${tRes.status}`); return new Response("ok", { status: 200 }); }
  const txn = await tRes.json();

  const txnCents = Math.round(Number(txn.amount ?? 0) * 100);
  const status   = String(txn.status ?? "").toUpperCase();
  const approved = status === "APPROVED";
    const currency = String(txn.currency ?? "USD").toUpperCase();

  // ── 6. Link to our payment row via the invoiceNumber we set at checkout ────
  //    (that is OUR invoice id, e.g. INV-3F9A2C1B7D). Nothing else is trusted.
  // Linking strategy, most reliable first. payment-checkout does not send an
  // invoiceNumber to Helcim, so matching on that alone would never hit -- which
  // silently disabled the webhook as a fallback authority.
  let pay: Record<string, unknown> | null = null;

  // 1. Already stamped by payment-validate.
  {
    const { data } = await sb.from("payments").select("*")
      .eq("provider", "helcim").eq("provider_transaction_id", txnId).maybeSingle();
    if (data) pay = data;
  }
  // 2. Helcim echoed our invoice number (only if a Helcim invoice was linked).
  const invoiceId = String(txn.invoiceNumber ?? "");
  if (!pay && invoiceId) {
    const { data } = await sb.from("payments").select("*")
      .eq("invoice_id", invoiceId).eq("provider", "helcim")
      .in("status", ["initiated", "pending", "unknown"])
      .order("created_at", { ascending: false }).limit(1).maybeSingle();
    if (data) pay = data;
  }
  // 3. Fallback: an in-flight attempt whose charged total is consistent with
  //    this transaction (base, or base + a Fee Saver amount) and recent.
  if (!pay) {
    const since = new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString();
    const { data: cands } = await sb.from("payments").select("*")
      .eq("provider", "helcim").eq("kind", "payment")
      .in("status", ["initiated", "pending", "unknown"])
      .gte("initiated_at", since)
      .order("initiated_at", { ascending: false }).limit(25);
    const hits = (cands ?? []).filter((c) => {
      const base = Number(c.amount_cents);
      return txnCents >= base && txnCents - base <= Math.max(Math.ceil(base * 0.10), 200);
    });
    // Only auto-link when it is unambiguous.
    if (hits.length === 1) pay = hits[0];
    else if (hits.length > 1) {
      await markProcessed(sb, whId, `ambiguous_match:${hits.length} candidates for ${txnCents}c`);
      return new Response("ok", { status: 200 });
    }
  }

  if (!pay) {
    // Could be a terminal/manual Helcim payment with no portal checkout. Record it,
    // but do not auto-mark the invoice: admin reconciles manually.
    await markProcessed(sb, whId, `no_matching_attempt txn=${txnId} amount=${txnCents}c`);
    return new Response("ok", { status: 200 });
  }

  // ── 7. Fee Saver aware amount reconciliation ───────────────────────────────
  // txnCents is the TOTAL charged. On card it legitimately exceeds the invoice
  // base by the convenience fee; on ACH it must match exactly.
  const rec = await reconcileAmount(sb, {
    baseCents: Number(pay.amount_cents), chargedCents: txnCents,
    currency, expectedCurrency: pay.currency, isACH: isBank,
  });
  if (!rec.ok) {
    await sb.from("payments").update({ status: "unknown", failure_category: `amount_${rec.reason}`,
      provider_transaction_id: txnId, total_charged_cents: txnCents,
      completed_at: new Date().toISOString() }).eq("id", pay.id);
    await sb.from("payment_events").insert({ payment_id: pay.id, invoice_id: pay.invoice_id, source: "webhook",
      event: "amount_mismatch", detail: { reason: rec.reason, base_cents: rec.baseCents,
        charged_cents: rec.totalCents, implied_fee_cents: rec.impliedFeeCents, currency, ach: isBank } });
    await markProcessed(sb, whId, `amount_${rec.reason} charged=${txnCents} base=${pay.amount_cents}`);
    return new Response("ok", { status: 200 });
  }

  // ── 8. Write the outcome ────────────────────────────────────────────────────
  // Card:  APPROVED is final → succeeded.
  // ACH:   APPROVED at initiation is NOT settlement. It stays 'pending' until
  //        the provider reports the bank transaction cleared (a later webhook
  //        or the reconcile job). Only a cleared/settled state → succeeded.
  const achSettled = isBank && /settl|clear|complet/i.test(String(txn.bankStatus ?? txn.settlementStatus ?? ""));
  const newStatus = !approved ? "failed" : (isBank && !achSettled) ? "pending" : "succeeded";
  const now = new Date().toISOString();
  await sb.from("payments").update({
    status: newStatus,
    provider_transaction_id: txnId,
    method: isBank ? "ach" : "card",
    method_display: mask(txn),
    fee_cents: rec.feeCents,
    total_charged_cents: rec.totalCents,
    failure_category: approved ? null : "declined",
    approved_at: approved ? (pay.approved_at ?? now) : pay.approved_at,
    settled_at:  newStatus === "succeeded" ? now : null,
    declined_at: approved ? null : now,
    completed_at: newStatus === "pending" ? null : now,
  }).eq("id", pay.id);
  await sb.from("payment_events").insert({ payment_id: pay.id, invoice_id: pay.invoice_id, source: "webhook",
    event: newStatus === "succeeded" ? "settled" : newStatus === "pending" ? "pending" : "declined",
    detail: { txn_id: txnId, event_type: eventType, ach: isBank,
      base_cents: rec.baseCents, fee_cents: rec.feeCents, charged_cents: rec.totalCents } });

  await sb.rpc("recalc_invoice_status", { p_invoice_id: pay.invoice_id });
  if (newStatus === "succeeded") {
    await sb.from("invoices").update({ paid_via: "helcim", payment_id: pay.id }).eq("id", pay.invoice_id);
    await sb.from("activity_log").insert({ action: "invoice_paid",
      detail: `${pay.invoice_id} paid via ${isBank ? "ACH" : "card"} — txn ${txnId}` });
  }

  await markProcessed(sb, whId, newStatus);
  return new Response("ok", { status: 200 });
});

async function markProcessed(sb: ReturnType<typeof createClient>, id: string, result: string) {
  await sb.from("payment_webhook_events").update({ processed_at: new Date().toISOString(), result }).eq("webhook_id", id);
}
function mask(t: Record<string, string>): string | null {
  if (t.cardNumber)        return `${t.cardType ?? "Card"} ····${String(t.cardNumber).slice(-4)}`;
  if (t.bankAccountNumber) return `Bank ····${String(t.bankAccountNumber).slice(-4)}`;
  return null;
}
function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
